# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady


class GPIO:
    def __init__(self):
        """
        函数功能： 创建GPIO对象
        注意事项：无
        返回值：GPIO对象创建成功，返回GPIO对象；GPIO对象创建失败，抛出ENOMEN异常。
        """
        pass

    def open(self, node: str):
        """
        函数功能：打开GPIO设备节点，并根据节点的配置信息初始化GPIO。
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def close(self):
        """
        函数功能：关闭GPIO设备
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def read(self):
        """
        函数功能：获取GPIO设备输入电平
        注意事项：无
        返回值：
            0：低电平。
            1：高电平。
            负整数：故障码。
        """
        pass

    def write(self, value: int):
        """
        函数功能： 设置GPIO设备输出电平
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def on(self, cb):
        """
        函数功能：设置GPIO设备中断回调函数
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass
