# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady

class I2C:
    def __init__(self):
        """
        函数功能：创建I2C对象
        注意事项：无
        返回值：I2C对象创建成功，返回I2C对象；I2C对象创建失败，抛出ENOMEN异常。
        """
        pass

    def open(self, node: str):
        """
        函数功能：打开I2C设备节点，并根据节点的配置信息初始化I2C。
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def close(self):
        """
        函数功能：关闭I2C设备
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def read(self, buf: bytearray):
        """
        函数功能：从I2C总线接收数据
        注意事项：无
        返回值：
            0或正整数：真实接收到的数据字节数。
            负整数：故障码。
        """
        pass

    def write(self, buf: bytearray):
        """
        函数功能：向I2C总线发送数据
        注意事项：无
        返回值：
            0或正整数：真实发送的数据字节数。
            负整数：故障码。
        """
        pass

    def memRead(self, buf: bytearray, memaddr: int, addrsize: int):
        """
        函数功能：从I2C设备指定地址读取一段数据
        注意事项：无
        返回值：
            0或正整数：真实接收到的数据字节数。
            负整数：故障码。
        """
        pass

    def memWrite(self, buf: bytearray, memaddr: int, addrsize: int):
        """
        函数功能：向I2C设备指定地址写一段数据
        注意事项：无
        返回值：
            0或正整数：真实接收到的数据字节数。
            负整数：故障码。
        """
        pass
