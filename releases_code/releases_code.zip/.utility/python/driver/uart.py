# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady

class UART:
    def __init__(self):
        """
        函数功能：创建UART对象
        注意事项：无
        返回值：UART对象创建成功，返回UART对象；UART对象创建失败，抛出ENOMEN异常。
        """
        pass

    def open(self, node: str):
        """
        函数功能：打开UART设备节点，并根据节点的配置信息初始化UART。
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def close(self):
        """
        函数功能：关闭UART设备
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def read(self, buf: bytearray):
        """
        函数功能：从UART接收指定字节数的数据。
        注意事项：无
        返回值：成功：0或者正整数，真实读到的数据字节数；失败：负整数。
        """
        pass

    def write(self, buf: bytearray):
        """
        函数功能：从UART发送指定字节数的数据。
        注意事项：无
        返回值：成功：0或者正整数，真实发送的数据字节数；失败：负整数。
        """
        pass

    def any(self):
        """
        函数功能：查看UART接收buffer中的数据长度
        注意事项：无
        返回值：成功：0或者Buffer中数据的长度；失败：负整数。
        """
        pass

    def on(self, cb):
        """
        函数功能：注册UART数据异步接收函数
        注意事项：无
        返回值：成功：0或者Buffer中数据的长度；失败：负整数。
        """
        pass
