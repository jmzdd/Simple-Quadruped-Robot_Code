# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady

class TIMER:
    ONE_SHOT = 1
    PERIODIC = 2

    def __init__(self, id: int):
        """
        函数功能：创建Timer对象
        注意事项：无
        返回值：TIMER对象成功，返回TIMER对象；TIMER对象创建失败，返回None
        """
        pass

    def open(self, period=1000, mode=2, callback=None):
        """
        函数功能：打开TIMER硬件定时器功能，并启动定时器
        注意事项：无
        返回值：打开TIMER设备成功返回0；打开TIMER设备失败返回失败错误码
        """
        pass

    def close(self):
        """
        函数功能：关闭硬件定时器
        注意事项：无
        返回值：关闭TIMER设备成功返回0；关闭TIMER设备失败返回失败错误码
        """
        pass

    def start(self):
        """
        函数功能： 打开硬件定时器，并开始计时
        注意事项：无
        返回值： 打开TIMER计时成功返回0；否则返回错误码；
        """
        pass

    def stop(self):
        """
        函数功能：关闭硬件定时器，并停止计时
        注意事项：无
        返回值： 关闭TIMER计时成功返回0；否则返回错误码；
        """
        pass

    def period(self, *args):
        """
        函数功能：设置定时器定时时间，并重新开始计时
        注意事项：无
        返回值：设置定时器成功返回0；否则返回错误码；
        """
        pass

    def reload(self):
        """
        函数功能：重启TIMER定时器，并根据之前的设置重新开始计时
        注意事项：需确保此TIMER处于open状态
        返回值：设置定时器成功返回0；否则返回错误码；
        """
        pass
