# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady

class WDT:
    def __init__(self):
        """
        函数功能：创建WDT对象
        注意事项：无
        返回值：WDT对象创建成功，返回WDT对象；WDT对象创建失败，抛出ENOMEN异常。
        """
        pass

    def open(self, node: str):
        """
        函数功能：打开WDT设备节点，并根据节点的配置信息初始化WDT。
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def feed(self):
        """
        函数功能：喂狗
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def close(self):
        """
        函数功能：关闭WDT设备
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass
