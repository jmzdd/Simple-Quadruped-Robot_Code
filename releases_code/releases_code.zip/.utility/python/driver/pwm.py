# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady


class PWM:

    def __init__(self):
        """
        函数功能：创建PWM对象
        注意事项：无
        返回值：
        """
        pass

    def open(self, node: str):
        """
        函数功能：根据board.json中设备节点的配置打开PWM设备
        注意事项：无
        返回值：
        """
        pass

    def close(self):
        """
        函数功能：关闭PWM脉宽调制功能
        注意事项：无
        返回值：
        """
        pass

    def setOption(self, opt_dict: dict):
        """
        函数功能：设置脉宽调制参数，包括freq和duty的值
        注意事项：无
        返回值：读取成功则返回0并按照设置的值输出PWM波形；负数代表读取数据失败
        """
        pass

    def getOption(self) -> dict:
        """
        函数功能：读取PWM设置的参数值
        注意事项：无
        返回值：读取成功返回参数字典，和设置的参数字典结构相同。
        """
        pass
