# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady

class ADC:
    def __init__(self):
        """
        函数功能： 创建ADC对象
        注意事项：无
        返回值：ADC对象成功，返回ADC对象；ADC对象创建失败，抛出ENOMEN异常
        """
        pass

    def open(self, node: str):
        """
        函数功能：根据board.json中设备节点的配置打开ADC设备
        注意事项：无
        返回值：打开ADC设备成功返回0；打开ADC设备失败返回失败错误码
        """
        pass

    def close(self):
        """
        函数功能：关闭数模转换设备
        注意事项：需确保要关闭的ADC处于open状态
        返回值：关闭ADC设备成功返回0；关闭ADC设备失败返回失败错误码
        """
        pass

    def readRaw(self):
        """
        函数功能：读取ADC原始数据
        注意事项：需确保此ADC处于open状态
        返回值：读取成功则返回读取到的原始值；负数代表读取数据失败
        """
        pass

    def readVoltage(self):
        """
        函数功能：读取ADC电压数据
        注意事项：需确保此ADC处于open状态
        返回值：读取成功则返回读取到的电压值；负数代表读取数据失败
        """
        pass
