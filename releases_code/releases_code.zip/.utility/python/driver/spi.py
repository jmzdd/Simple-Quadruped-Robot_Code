# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady

class SPI:
    def __init__(self):
        """
        函数功能：创建SPI对象
        注意事项：无
        返回值：SPI对象创建成功，返回SPI对象；SPI对象创建失败，抛出ENOMEN异常。
        """
        pass

    def open(self, node):
        """
        函数功能：打开SPI设备节点，并根据节点的配置信息初始化SPI。
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def close(self):
        """
        函数功能：关闭SPI设备
        注意事项：无
        返回值：成功：0；失败：故障码。
        """
        pass

    def read(self, buf: bytearray):
        """
        函数功能：从SPI总线接收数据
        注意事项：无
        返回值：
            0或正整数：真实接收到的数据字节数。
            负整数：故障码。
        """
        pass

    def write(self, buf: bytearray):
        """
        函数功能： 向SPI总线发送数据
        注意事项：无
        返回值：
            0或正整数：真实发送的数据字节数。
            负整数：故障码。
        """
        pass

    def readAfterWrite(self, read_buf: bytearray, write_buf: bytearray):
        """
        函数功能：先发送后接收数据
        注意事项：无
        返回值：
            0或正整数：真实接收到的数据字节数。
            负整数：故障码。
        """
        pass
