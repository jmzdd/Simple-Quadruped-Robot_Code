# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady


def start():
    """
    函数功能：启用配网功能，并作为服务一直运行在后台。
    注意事项：
         - 此方法会影响原有的蓝牙功能。
         - 当此函数发起后，会进行蓝牙广播，设备可以被发现为"esp-node"。
    返回值：成功返回0，失败时会抛出异常。
    """
    pass


def getBleStatus():
    """
    函数功能：该方法返回蓝牙配网状态。
    注意事项：
        - 该方法只关心配网过程中蓝牙交互的状态。
        - WLAN有关的状态，开发者可以通过调用 bleNetConfig.getWiFiStatus() 方法获取。
    返回值：返回配网状态
        - 0 ： 设备蓝牙已连接
        - 1 ： 设备蓝牙已断开
        - 2 ： 设备已正在进行蓝牙数据交互
    """
    pass


def getWLAN():
    """
    函数功能：该方法返回蓝牙配网底层使用的 network.WLAN 对象。 该方法同 network.WLAN(network.STA_IF) 的返回相同，获取的是同一个全局对象。
    注意事项：无
    返回值：成功返回0，失败时会抛出异常。
    """
    pass

def getWiFiStatus():
    """
    函数功能：该方法返回WiFi连接状态。
    注意事项：无
    返回值：成功返回0，失败时会抛出异常。
    """
    pass

def getWiFiConfig():
    """
    函数功能：获取IP级网络接口参数：IP 地址、子网掩码、网关和 DNS服务器。
    注意事项：无
    返回值：此方法返回一个包含 IP 地址、子网掩码、网关和 DNS服务器 的 4 元组。
    """
    pass

def stop():
    """
    函数功能： 停止配网
    注意事项：无
    返回值：成功返回0，失败时会抛出异常。
    """
    pass
