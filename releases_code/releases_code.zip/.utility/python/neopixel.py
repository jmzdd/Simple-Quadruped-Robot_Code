class NeoPixel:
    ""
    ORDER = None

    def fill():
        pass

    def write():
        pass


def neopixel_write():
    pass
