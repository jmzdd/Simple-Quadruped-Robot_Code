class FlashBdev:
    ""
    SEC_SIZE = 4096
    START_SEC = 512

    def ioctl():
        pass

    def readblocks():
        pass

    def writeblocks():
        pass


bdev = None
esp = None
size = 4194304
