#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
'''
* @file         http.py
* @author       guoliang.wgl
* @version      V01
* @date         2021.12.01
* @brief         
* @note          
* @attention    guoliang.wgl
'''


def request(data: dict, func):
    """
    函数功能：发起一个HTTP请求
    注意事项：需确保此网络已经连接
    返回值：异步接口，请求发送成功返回0；失败返回其他负数值
    """
    pass


def download(data: dict, func):
    """
    函数功能：下载文件到本地
    注意事项：需确保此网络已经连接
    返回值：异步接口，下载发送成功返回0；失败返回其他负数值
    """
    pass
