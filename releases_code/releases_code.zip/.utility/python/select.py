POLLERR = 8
POLLHUP = 16
POLLIN = 1
POLLOUT = 4


def poll():
    pass


def select():
    pass
