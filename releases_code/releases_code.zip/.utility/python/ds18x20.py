class DS18X20:
    ""

    def convert_temp():
        pass

    def read_scratch():
        pass

    def read_temp():
        pass

    def scan():
        pass

    def write_scratch():
        pass


def const():
    pass
