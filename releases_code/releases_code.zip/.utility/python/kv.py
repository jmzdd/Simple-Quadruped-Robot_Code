#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
'''
* @file         kv.py
* @author       guoliang.wgl
* @version      V01
* @date         2021.12.01
* @brief         
* @note          
* @attention    guoliang.wgl
'''


def set(key: str, value: str):
    """
    函数功能：写入kv键值对
    返回值：kv键值对写入成功返回0；写入失败返回非0
    """
    pass


def get(key: str):
    """
    函数功能：根据key值获取value值
    返回值：键值对中的value值
    """
    pass


def remove(key: str):
    """
    函数功能： 删除kv键值对
    返回值：kv键值对删除成功返回0；删除失败返回非0
    """
    pass
