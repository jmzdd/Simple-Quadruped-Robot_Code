def wrap_socket():
    pass
