#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
'''
* @file         aliyunIoT.py
* @author       guoliang.wgl
* @version      V01
* @date         2021.12.01
* @brief         
* @note          
* @attention    guoliang.wgl
'''

class Device:

    ON_CONNECT = 1
    ON_DISCONNECT = 3
    ON_CLOSE = 2
    ON_SERVICE = 5
    ON_SUBCRIBE = 6
    ON_PROPS = 7
    ON_ERROR = 8
    ON_RAWDATA = 10

    def __init__(self):
        pass

    def register(self, device_info: dict, cb):
        """
        函数功能：设备动态注册，用于一型一密设备获取deviceSecret。
        注意事项：首先确保网络连接成功。确保物联网平台产品、设备创建成功 。
        返回值说明：成功，0； 失败，非0整数
        """
        pass

    def connect(self, device_info: dict):
        """
        函数功能：连接物联网平台。
        注意事项：确保网络连接成功。
        返回值说明：成功返回0， 其他表示失败
        """
        pass

    def on(self, event_type: int, cb):
        """
        函数功能：注册device的回调函数，在相应事件触发时开始时触发。
        注意事项：确保网络以及物联网平台连接成功
        """
        pass

    def getDeviceInfo(self):
        """
        函数功能：获得保存在该设备上的设备信息。
        注意事项：读取之前需要首先确认设备信息是否保存过。
        返回值说明：成功，设备信息（deviceInfo结构，字典类型）；失败，None
        """
        pass

    def getDeviceHandle(self):
        """
        函数功能：获得Device实例句柄
        注意事项：确保已经成功创建过Device实例。
        返回值说明：成功，Device实例；失败，None
        """
        pass

    def getNtpTime(self, cb):
        """
        函数功能：从物联网平台获得网络时间
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明：成功，时间信息（字典类型，data） ；失败，非0整数
        """
        pass

    def postProps(self, data: dict):
        """
        函数功能：上报设备属性
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明：成功，0；失败，非0整数
        """
        pass

    def postEvent(self, data: dict):
        """
        函数功能：上报标准事件，格式见参数说明。
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明：成功，0；失败，非0整数
        """
        pass

    def postRaw(self, data: dict):
        """
        函数功能：上报自定义（Raw）数据。
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明：成功，0；失败，非0整数
        """
        pass

    def uploadFile(self, remote_file, local_file, callback):
        """
        函数功能：上传文件到物联网平台。
        注意事项： 确保网络以及物联网平台连接成功； 上传的文件以及字符须准确并符合命名规范； 文件大小需小于16MB，如超过请使用oss接口。
        返回值说明：成功，uploadID（字符串类型）；失败，None
        """
        pass

    def uploadContent(self, remote_file,  content,  callback):
        """
        函数功能：上传文件数据流，上传数据保存为指定文件文件名由参数指定。
        注意事项： 确保网络以及物联网平台连接成功。 上传的文件以及字符须准确并符合命名规范。 文件大小需小于16MB，超过请使用oss接口。
        返回值说明：成功，uploadID（字符串类型）；失败，None
        """
        pass

    def subscribe(self, topic_info: dict):
        """
        函数功能： 用于自定义Topic订阅。
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明：成功，0；失败，非0整数
        """
        pass

    def unsubscribe(self, topic_info: dict):
        """
        函数功能：取消订阅自定义topic。
        注意事项：确保网络以及物联网平台连接成功，并且该topic已经订阅。
        回值说明： 成功，0；失败，非0整数
        """
        pass

    def publish(self, topic_info: dict):
        """
        函数功能：发布消息到指定topic。
        注意事项：确保网络以及物联网平台连接成功并且已经创建对象，确保已经订阅该topic。
        返回值说明：成功：0, 失败：非0整数
        """
        pass

    def end(self):
        """
        函数功能：close gateway对象，销毁资源。
        注意事项：无
        返回值说明： 成功，0；失败，非0整数。
        """
        pass



class Gateway:

    ON_CONNECT = 0
    ON_DISCONNECT = 1
    ON_CLOSE = 2
    ON_SUBCRIBE = 3
    ON_LOGIN = 4
    ON_LOGOUT = 5
    ON_TOPOADD = 6
    ON_TOPOREMOVE = 7
    ON_TOPOGET = 8
    ON_SUBREGISTER = 9

    def __init__(self):
        pass

    def connect(self, data: dict):
        """
        函数功能：通过已经申请好的三元组信息连接物联网平台。
        注意事项：确保网络连接成功并且已经创建gateway对象。
        返回值： 成功返回0， 其他表示失败。
        """
        pass

    def on(self, event_type: int, cb):
        """
        函数功能：注册Gateway的回调函数，在相应事件触发时回调。
        注意事项：确保网络以及物联网平台连接成功。
        """
        pass

    def getGatewayInfo(self):
        """
        函数功能：获得保存在该设备上的设备信息。
        注意事项：读取之前需要首先确认设备信息是否保存过。
        """
        pass

    def getGatewayHandle(self):
        """
        函数功能：获得gateway实例句柄, 用于其他模块使用。
        注意事项：确保已经创建getway对象。
        参数说明：无
        返回值说明：成功，gateway实例；失败，None。
        函数示例：
        """
        pass

    def getNtpTime(self, callback):
        """
        函数功能：从物联网平台获得网络时间。
        注意事项：确保网络以及物联网平台连接成功并且已经创建gateway对象。
        返回值说明：成功：Gateway实例，失败：None
        """
        pass

    def uploadFile(self, remote_file, local_file, callback):
        """
        函数功能：上传文件到物联网平台。
        注意事项： 确保网络以及物联网平台连接成功； 上传的文件以及字符须准确并符合命名规范； 文件大小需小于16MB，如超过请使用oss接口。
        返回值说明：成功，uploadID（字符串类型）；失败，None
        """
        pass

    def uploadContent(self, remote_file,  content,  callback):
        """
        函数功能：上传文件数据流，上传数据保存为指定文件文件名由参数指定。
        注意事项： 确保网络以及物联网平台连接成功。 上传的文件以及字符须准确并符合命名规范。 文件大小需小于16MB，超过请使用oss接口。
        返回值说明：成功，uploadID（字符串类型）；失败，None
        """
        pass

    def addTopo(self, sub_device_info: dict):
        """
        函数功能：对网关设备添加子设备。
        注意事项：确保网络以及物联网平台连接成功并且已经创建gateway对象。网关设备跟子设备需要提前注册。
        返回值说明： 成功：0，失败：非0整数。
        """
        pass

    def getTopo(self):
        """
        函数功能：获得该网关已经添加过子设备列表，结果在msg中查看。
        注意事项：确保网络以及物联网平台连接成功。操作之前确保已经添加了子设备到该网关。
        返回值说明：成功，0；失败，非0整数
        """
        pass

    def removeTopo(self, sub_device_info: dict):
        """
        函数功能：从网关中删除子设备。
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明： 成功，0；失败，非0整数
        """
        pass

    def login(self, sub_device_info: dict):
        pass

    def logout(self, sub_device_info: dict):
        
        pass

    def registerSubDevice(self, sub_device_info: dict):
        """
        函数功能：子设备动态注册，用于一型一密量产的设备。
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明： 成功：0，失败：非0整数
        """
        pass

    def subscribe(self, topic_info: dict):
        """
        函数功能： 用于自定义Topic订阅。
        注意事项：确保网络以及物联网平台连接成功。
        返回值说明：成功，0；失败，非0整数
        """
        pass

    def unsubscribe(self, topic_info: dict):
        """
        函数功能：取消订阅自定义topic。
        注意事项：确保网络以及物联网平台连接成功，并且该topic已经订阅。
        回值说明： 成功，0；失败，非0整数
        """
        pass

    def publish(self, topic_info: dict):
        """
        函数功能：发布消息到指定topic。
        注意事项：确保网络以及物联网平台连接成功并且已经创建对象，确保已经订阅该topic。
        返回值说明：成功：0, 失败：非0整数
        """
        pass

    def end(self):
        """
        函数功能：close gateway对象，销毁资源。
        注意事项：无
        返回值说明： 成功，0；失败，非0整数。
        """
        pass

