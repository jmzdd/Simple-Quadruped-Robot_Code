# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady


class Player:
    def __init__(self):
        """
        函数功能：创建Player对象
        返回值：Player对象成功，返回PlayerT对象；Player对象创建失败，返回None
        """
        pass

    def open(self):
        """
        函数功能：打开播放器
        返回值：打开Player成功返回0；打开Player失败返回失败错误码
        """
        pass

    def close(self):
        """
        函数功能：关闭播放器
        注意事项：需确保要关闭的播放器处于open状态
        返回值：关闭Player设备成功返回0；关闭Playe设备失败返回失败错误码
        """
        pass

    def play(self, uri: str, sync: bool):
        """
        函数功能：播放音频文件，可以播放本地文件或者网络文件
        注意事项：需确保此Player处于open状态
        返回值：播放成功则返回0，播放失败返回错误码。
        """
        pass

    def stop(self):
        """
        函数功能：播放器停止
        注意事项： 需确保证Player处于打开状态
        返回值：成功则返回0，失败返回错误码
        """
        pass

    def pause(self):
        """
        函数功能：播放器暂停
        注意事项：需确保证Player处于正在播放状态
        返回值：成功则返回0，失败返回错误码
        """
        pass

    def resume(self):
        """
        函数功能：播放器恢复播放
        注意事项：需确保证Player处于pause状态
        返回值：成功则返回0，失败返回错误码
        """
        pass

    def setVolume(self, volume: int):
        """
        函数功能：播放器设置音量
        注意事项：无
        返回值：成功则返回0，失败返回错误码
        """
        pass

    def getVolume(self):
        """
        函数功能：播放器获取音量
        注意事项：无
        返回值：成功则返回当前音量，失败返回错误码
        """
        pass

    def getState(self):
        """
        函数功能：播放器获取播放状态
        注意事项：无
        返回值：返回播放器当前播放状态
        """
        pass

    def getPosition(self):
        """
        函数功能： 播放器获取播放位置
        注意事项：
        返回值：返回播放器当前播放位置，单位是毫秒
        """
        pass

    def getDuration(self):
        """
        函数功能： 播放器获取音频文件时长
        注意事项：
        返回值：返回当前音频文件时长，单位是毫秒
        """
        pass

    def seek(self, seek_time_sec: int):
        """
        函数功能： 播放器播放进度控制
        注意事项：单位是s
        返回值：成功则返回0，失败返回错误码
        """
        pass

    def on(self, callback):
        """
        函数功能： 注册Player异步回调函数
        注意事项：
        返回值：返回播放器当前播放位置，单位是毫秒
        """
        pass
