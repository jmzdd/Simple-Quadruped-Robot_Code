# ！/usr/bin/python3
# -- coding: utf-8 --
# @Time : 2022/5/27 11:47 AM
# @Author : grady


def init(came_type: str, rx=None, tx=None):
    """
    函数功能：初始化摄像头
    返回值：成功返回0，失败返回-1
    """
    pass


def capture():
    """
    函数功能：获取摄像头画面
    注意事项： 获取的图像格式为JPEG
    返回值：正常返回bytes格式的jpeg图像数据，失败返回None
    """
    pass


def save(frame, path: str):
    """
    函数功能：保存摄像头画面到文件系统中
    返回值：正常返回0，失败返回-1
    """
    pass


def setProp(cmd, value):
    """
    函数功能：设置摄像头属性
    注意事项：目前主要针对Uart摄像头进行设置，设置后重新启动生效
    返回值：正常返回0，失败返回-1
    """
    pass