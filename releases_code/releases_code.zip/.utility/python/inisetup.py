bdev = None


def check_bootsec():
    pass


def fs_corrupted():
    pass


def setup():
    pass


uos = None
