#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
'''
* @file         ota.py
* @author       guoliang.wgl
* @version      V01
* @date         2021.12.01
* @brief         
* @note          
* @attention    guoliang.wgl
'''

def init(param1):
    pass


def report(param1):
    pass


def on(param1, param2):
    pass


def download(param1):
    pass


def verify(param1):
    pass


