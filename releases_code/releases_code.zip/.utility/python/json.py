def dump():
    pass


def dumps():
    pass


def load():
    pass


def loads():
    pass
