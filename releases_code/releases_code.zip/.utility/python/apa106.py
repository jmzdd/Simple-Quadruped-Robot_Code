class APA106:
    ""
    ORDER = None

    def fill():
        pass

    def write():
        pass


class NeoPixel:
    ""
    ORDER = None

    def fill():
        pass

    def write():
        pass
