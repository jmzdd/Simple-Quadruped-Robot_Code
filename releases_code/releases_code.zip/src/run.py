from driver import I2C
from utime import sleep_ms
from time import sleep
import pca9685
import property
import utd

i2cObj = I2C()
i2cObj.open("pca9685")
robot=pca9685.PCA9685(i2cObj)


delay_ms = 20
delay = 0.05
run_on_list = [[6,-0.5], [10,0.5], [8,0], [4,-1],
                [6,0], [10,0], [2,0.5], [14,-0.5],
                [0,-0.5], [12,0], [4,0], [8,1],
                [2,0], [14,0], [0,0], [12,1]]
run_turn_list = [[14, -0.5], [12, 0], [14, 0], [6, -0.5],
                [4, -1], [6, 0], [2, 0.5], [8, 0], [12, 1],
                [4, 0], [2, 0], [10, 0.5], [8, 1], [10, 0]]

def run_init():
    robot.setServo(0, 0)
    robot.setServo(2, 0)
    robot.setServo(4, 0)
    robot.setServo(6, 0)
    robot.setServo(8, 1)
    robot.setServo(10, 0)
    robot.setServo(12, 1)
    robot.setServo(14, 0)
    property.run_init_db(0)

def run_on():
    utd.utd_fuc()
    # 超声波距离判断
    if utd.distance <= 50:
        sleep(1)
        run_turn()
    else:
        for Angle_num in run_on_list:
            print(Angle_num)
            robot.setServo(Angle_num[0],Angle_num[1])
            sleep_ms(delay_ms)



# def run_turn():
#     for turn_num in run_turn_list:
#         print(turn_num)
#         robot.setServo(turn_num[0], turn_num[1])
#         sleep_ms(delay_ms)

# 步态原理：将四只脚看作两组处理，前两只脚一组，后两只脚一组。两只脚交替向前，两组脚的左右脚交替动作
# def run_test_on():
#     # 右前脚抬起
#     robot.setServo(6, -0.5)
#     sleep_ms(delay_ms)
#     # 左后脚抬起
#     robot.setServo(10, 0.5)
#     sleep_ms(delay_ms)
#     # 左后脚伸出
#     robot.setServo(8, 0)
#     sleep_ms(delay_ms)
#     # 右前脚伸出
#     robot.setServo(4, -1)
#     sleep_ms(delay_ms)
#     # 右前脚落下
#     robot.setServo(6, 0)
#     sleep_ms(delay_ms)
#     # 左后脚落下
#     robot.setServo(10, 0)
#     sleep_ms(delay_ms)
#     # 左前脚抬起
#     robot.setServo(2, 0.5)
#     sleep_ms(delay_ms)
#     # 右后脚抬起
#     robot.setServo(14, -0.5)
#     sleep_ms(delay_ms)
#     # 左前脚伸出
#     robot.setServo(0, -1.5)
#     sleep_ms(delay_ms)
#     # 右后脚伸出
#     robot.setServo(12, 0)
#     sleep_ms(delay_ms)
#     # 右前脚归位
#     robot.setServo(4, 0)
#     sleep_ms(delay_ms)
#     # 左后脚归位
#     robot.setServo(8, 1)
#     sleep_ms(delay_ms)
#     # 左前脚落下
#     robot.setServo(2, 0)
#     sleep_ms(delay_ms)
#     # 右后脚落下
#     robot.setServo(14, 0)
#     sleep_ms(delay_ms)
#     # 左前脚归位
#     robot.setServo(0, 0)
#     sleep_ms(delay_ms)
#     # 右后脚归位
#     robot.setServo(12, 1)
#     sleep_ms(delay_ms)

def run_turn():
    utd.utd_fuc()
    # 超声波距离判断
    if utd.distance >= 50:
        sleep(1)
        run_on()
    else:
        robot.setServo(14, -0.5)
        sleep_ms(delay_ms)
        robot.setServo(12, 0)
        sleep_ms(delay_ms)
        robot.setServo(14, 0)
        sleep_ms(delay_ms)
        robot.setServo(6, -0.5)
        sleep_ms(delay_ms)
        robot.setServo(4, -1)
        sleep_ms(delay_ms)
        robot.setServo(6, 0)
        sleep_ms(delay_ms)
        robot.setServo(2, 0.5)
        sleep_ms(delay_ms)
        robot.setServo(8, 0)
        sleep_ms(delay_ms)
        robot.setServo(12, 1)
        sleep_ms(delay_ms)
        robot.setServo(4, 0)
        sleep_ms(delay_ms)
        robot.setServo(2, 0)
        sleep_ms(delay_ms)
        robot.setServo(10, 0.5)
        sleep_ms(delay_ms)
        robot.setServo(8, 1)
        sleep_ms(delay_ms)
        robot.setServo(10, 0)
        sleep_ms(delay_ms)
