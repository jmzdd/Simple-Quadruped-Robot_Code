import hcsr04
from driver import GPIO
import property

echoDev = GPIO()
echoDev.open("echo")

trigDev = GPIO()
trigDev.open("trig")

def utd_fuc():
    global distance
    hcsr04Dev = hcsr04.HCSR04(trigDev,echoDev)
    distance = hcsr04Dev.measureDistance()
    property.distance_db(distance)


