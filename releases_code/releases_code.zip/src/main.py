from web import blecloud
from property import property_update
from run import *

# 进入蓝牙联网状态，并连接云平台
blecloud()

# 上报本地机器人属性
property_update()

# 机器人初始化姿态，等待指令
run_init()
