import json
import web
import utime
from run import *
from lib_thread import *

global run_on_task
run_on_task = Task(run_on,0)

def property_update():
    # 设置属性值
    Network = {'network' : 1}
    Gesture = {'gesture' : 0}
    Forward = {'forward' : 0}
    Turn = {'turn' : 0}
    Network_prop = {'params': json.dumps(Network)}
    Gesture_prop = {'params': json.dumps(Gesture)}
    Forward_prop = {'params': json.dumps(Forward)}
    Turn_prop = {'params': json.dumps(Turn)}
    # 上传属性值：这里用for循环语句循环两次，因为如果只上报一次返回值不是0（就是没报上去），报两次就可以了（我也不知道为什么）。
    # 可能的原因以及解决方案：个人猜测是由于网络延时，单片机与云服务器通信需要时间，返回没那么快。可以考虑一直输出返回值，自行计算对应时间并在代码中做适当延时。
    for i in range(0,2):
        ret = web.aliyunIoT_device.postProps(Network_prop)
        web.aliyunIoT_device.postProps(Gesture_prop)
        web.aliyunIoT_device.postProps(Forward_prop)
        web.aliyunIoT_device.postProps(Turn_prop)
        # 判断返回值
        if ret == 0 :
            utime.sleep(1)
            print('属性上报成功')
        else:
            utime.sleep(1)
            print('属性上报失败')

# 物联网平台控制消息返回函数（这部分包含机器人的控制逻辑）
def on_props(request):
    payload = json.loads(request['params'])
    # 获取dict状态字段 注意要验证键存在 否则会抛出异常
    if "forward" in payload.keys():
        forward_ret = payload["forward"]
        # 判断是否按下前进按钮
        if forward_ret == 1:
            run_on_db(1)
            sleep(1)
            run_on_db(1)
            # 启动机器人运动线程
            run_on_task.start()
        elif forward_ret == 0:
            run_on_db(0)
            sleep(1)
            run_on_db(0)
            # 暂停机器人运动线程
            run_on_task.stop()
        elif "turn" in payload.keys():
            turn_ret = payload["turn"]
            if turn_ret == 1:
                turn_db(1)
                run_turn()
                turn_db(0)

# 下面为控制返回函数（主要是返回属性值到物联网平台）
def distance_db(num):
    temp = 2
    Distance = {'distance' : num}
    utd_db = {'params' : json.dumps(Distance)}
    while temp > 0:
        web.aliyunIoT_device.postProps(utd_db)
        temp -= 1

def turn_db(sw_turn):
    if sw_turn == 1:
        Turn = {'turn' : 1}
        run_turn_db = {'params': json.dumps(Turn)}
        web.aliyunIoT_device.postProps(run_turn_db)
    elif sw_turn == 0:
        Turn = {'turn' : 0}
        run_turn_db = {'params': json.dumps(Turn)}
        web.aliyunIoT_device.postProps(run_turn_db)

def run_on_db(sw_run):
    if sw_run == 1:
        Forward = {'forward' : 1}
        run_forward_db = {'params' : json.dumps(Forward)}
        web.aliyunIoT_device.postProps(run_forward_db)
    elif sw_run == 0:
        Forward = {'forward' : 0}
        run_forward_db = {'params' : json.dumps(Forward)}
        web.aliyunIoT_device.postProps(run_forward_db)

def run_init_db(sw_run_init):
    if sw_run_init == 1:
        Gesture = {'gesture' : 1}
        run_forward_db = {'params' : json.dumps(Gesture)}
        web.aliyunIoT_device.postProps(run_forward_db)
    elif sw_run_init == 0:
        Gesture = {'gesture' : 0}
        run_forward_db = {'params' : json.dumps(Gesture)}
        web.aliyunIoT_device.postProps(run_forward_db)
