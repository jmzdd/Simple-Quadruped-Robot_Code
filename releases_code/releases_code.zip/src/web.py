import bleNetConfig
import time
from aliyunIoT import Device
import utime
import property



#启动蓝牙配网
def blecloud():
    bleNetConfig.start()
    while(bleNetConfig.getWiFiStatus() != bleNetConfig.WIFI_GOT_IP):
    #判断蓝牙配网的状态信息
        bleStatus = bleNetConfig.getBleStatus()
        if(bleStatus == bleNetConfig.BLE_CONNECTED):
            print('蓝牙已连接')
            time.sleep(1)
        elif(bleStatus == bleNetConfig.BLE_DISCONNECTED):
            print('蓝牙已断开')
            time.sleep(1)
        elif(bleStatus == bleNetConfig.BLE_COMMINICATING):
            print('正在通过蓝牙交互中')
            time.sleep(1)
    print('Wi-Fi已连接')
    time.sleep(1)
    bleNetConfig.stop()

    #准备连入阿里云物联网平台
    iot_connected = False
    #物联网连接成功的回调函数
    def on_connect(data):
        global iot_connected
        iot_connected = True
    #云服务器三元组参数
    key_info = {
        'region': 'cn-shanghai',
        'productKey': '请自行填写',
        'deviceName': '请自行填写',
        'deviceSecret': '请自行填写',
        'keepaliveSec': 60
    }

    global aliyunIoT_device

    # 将三元组信息设置到iot组件中
    aliyunIoT_device = Device()

    # 设定连接到物联网平台的回调函数，如果连接物联网平台成功，则调用on_connect函数
    aliyunIoT_device.on(aliyunIoT_device.ON_CONNECT, on_connect)

    # 如果收到物联网平台发送的属性控制消息
    aliyunIoT_device.on(aliyunIoT_device.ON_PROPS, property.on_props)

    # 启动连接阿里云物联网平台过程
    aliyunIoT_device.connect(key_info)
    # 等待设备成功连接到物联网平台

    while(True):
        if not iot_connected:
            print('物联网平台连接成功')
            break
        else:
            print('连接失败请重试')
            utime.sleep(1)
            break
